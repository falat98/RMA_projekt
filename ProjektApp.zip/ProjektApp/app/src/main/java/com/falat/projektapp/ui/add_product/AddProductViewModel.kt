package com.falat.projektapp.ui.add_product

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.falat.projektapp.model.Product
import com.falat.projektapp.repository.ProductRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AddProductViewModel(private val productRepository: ProductRepository) : ViewModel() {

    fun insertProduct(product: Product) {
        viewModelScope.launch(Dispatchers.IO) {
            productRepository.insertProduct(product)
        }
    }
}
