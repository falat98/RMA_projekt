package com.falat.projektapp.ui.main

import android.annotation.SuppressLint
import android.util.Log
import androidx.lifecycle.ViewModel
import com.falat.projektapp.model.Product
import com.falat.projektapp.repository.ProductRepository
import java.text.SimpleDateFormat
import java.util.Calendar

class MainViewModel(productRepository: ProductRepository) : ViewModel() {

    val products = productRepository.readAllProducts()
    val productsExpiringToday = mutableSetOf<Product>()

    @SuppressLint("SimpleDateFormat")
    fun checkProductsForExpiring(products: List<Product>) {
        val calendar = Calendar.getInstance()
        val simpleCurrentDate = SimpleDateFormat("ddMMyyyy").format(calendar.time)
        for (product in products) {
            val simpleProductDate = SimpleDateFormat("ddMMyyyy").format(product.productExpirationDate)
            if (simpleProductDate == simpleCurrentDate) {
                productsExpiringToday.add(product)
                Log.d("PRODUCTS", productsExpiringToday.size.toString())
            }
        }
    }
}
