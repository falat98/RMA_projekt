package com.falat.projektapp.ui.product_overview

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.falat.projektapp.R
import com.falat.projektapp.model.Product

class ProductOverviewAdapter : RecyclerView.Adapter<ProductOverviewViewHolder>() {

    private val products = mutableListOf<Product>()

    fun setProducts(products: List<Product>) {
        this.products.clear()
        this.products.addAll(products)
        this.notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductOverviewViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false)
        return ProductOverviewViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductOverviewViewHolder, position: Int) {
        val product = products[position]
        holder.bind(product)
    }

    override fun getItemCount(): Int = products.count()

}
