package com.falat.projektapp.repository

import androidx.lifecycle.LiveData
import com.falat.projektapp.model.Product
import com.falat.projektapp.room.ProductDao

class ProductRepository(private val productDao: ProductDao) {

    suspend fun insertProduct(product: Product) {
        productDao.insertProduct(product)
    }

    fun readAllProducts(): LiveData<List<Product>> {
        return productDao.readAllProducts()
    }
}
