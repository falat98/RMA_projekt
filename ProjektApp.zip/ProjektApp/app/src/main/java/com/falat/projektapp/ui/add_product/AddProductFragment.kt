package com.falat.projektapp.ui.add_product

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.falat.projektapp.R
import com.falat.projektapp.databinding.FragmentAddProductBinding
import com.falat.projektapp.model.Product
import com.falat.projektapp.utils.getDate
import org.koin.androidx.viewmodel.ext.android.viewModel

class AddProductFragment : Fragment() {

    private lateinit var binding: FragmentAddProductBinding
    private val addProductViewModel: AddProductViewModel by viewModel()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentAddProductBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnSave.setOnClickListener { saveProduct() }
    }

    private fun saveProduct() {
        val productName = binding.etProductName.text.toString()
        val productExpirationDate = binding.dpExpirationDate.getDate()
        val product = Product(0, productName, productExpirationDate)

        addProductViewModel.insertProduct(product)

        Toast.makeText(requireContext(), R.string.saved, Toast.LENGTH_SHORT).show()

        val action = AddProductFragmentDirections.actionAddProductFragmentToHomeFragment()
        findNavController().navigate(action)
    }
}
