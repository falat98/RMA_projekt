package com.falat.projektapp.ui.product_overview

import androidx.lifecycle.ViewModel
import com.falat.projektapp.repository.ProductRepository

class ProductOverviewViewModel(productRepository: ProductRepository) : ViewModel() {

    val products = productRepository.readAllProducts()
}
