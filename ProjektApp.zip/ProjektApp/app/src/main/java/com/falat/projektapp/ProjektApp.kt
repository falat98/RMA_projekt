package com.falat.projektapp

import android.app.Application
import com.falat.projektapp.di.repositoryModule
import com.falat.projektapp.di.roomModule
import com.falat.projektapp.di.viewModelModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.GlobalContext

class ProjektApp : Application() {

    override fun onCreate() {
        super.onCreate()
        GlobalContext.startKoin {
            androidContext(this@ProjektApp)
            modules(
                roomModule,
                repositoryModule,
                viewModelModule,
            )
        }
    }
}
