package com.falat.projektapp.di

import androidx.room.Room
import com.falat.projektapp.repository.ProductRepository
import com.falat.projektapp.room.ProductDatabase
import com.falat.projektapp.ui.add_product.AddProductViewModel
import com.falat.projektapp.ui.main.MainViewModel
import com.falat.projektapp.ui.product_overview.ProductOverviewViewModel
import org.koin.android.ext.koin.androidApplication
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val roomModule = module {

    single {
        Room.databaseBuilder(
            androidApplication(),
            ProductDatabase::class.java,
            "product_database"
        ).allowMainThreadQueries().build()
    }
    single { get<ProductDatabase>().productDao() }
}

val repositoryModule = module {

    single { ProductRepository(get()) }
}

val viewModelModule = module {
    viewModel { AddProductViewModel(get()) }
    viewModel { ProductOverviewViewModel(get()) }
    viewModel { MainViewModel(get()) }
}
