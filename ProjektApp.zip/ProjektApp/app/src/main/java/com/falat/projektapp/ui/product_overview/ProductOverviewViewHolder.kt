package com.falat.projektapp.ui.product_overview

import android.annotation.SuppressLint
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.falat.projektapp.databinding.ItemProductBinding
import com.falat.projektapp.model.Product
import java.text.SimpleDateFormat

class ProductOverviewViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    @SuppressLint("SimpleDateFormat")
    fun bind(product: Product) {
        val binding = ItemProductBinding.bind(itemView)
        binding.tvProductName.text = product.productName
        binding.tvProductExpirationDate.text = SimpleDateFormat("dd.MM.yyyy").format(product.productExpirationDate)
    }
}
