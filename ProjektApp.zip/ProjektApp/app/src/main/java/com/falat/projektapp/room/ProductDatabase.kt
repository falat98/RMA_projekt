package com.falat.projektapp.room

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.falat.projektapp.model.Product

@Database(entities = [Product::class], version = 1, exportSchema = false)
@TypeConverters(com.falat.projektapp.room.TypeConverters::class)
abstract class ProductDatabase : RoomDatabase() {

    abstract fun productDao(): ProductDao
}
